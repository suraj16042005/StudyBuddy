/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ['class'],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)',
      },
      colors: {
        // Base & Neutral Colors (derived from Neutral M3 Grey and existing dark background)
        border: '#2F2F2F', // Dark border for contrast
        input: 'hsl(var(--input))', // Shadcn default
        ring: 'hsl(var(--ring))',   // Shadcn default
        background: '#171717', // Very dark main background
        foreground: '#FFFFFF', // Main text color on background
        surface: '#6B7280',    // Neutral M3 Grey - for cards, panels, etc.
        'on-surface': '#FFFFFF', // Text color on surface (white for contrast on grey)
        'on-surface-variant': '#A3A3A3', // Secondary text color on surface (lighter grey)
        muted: {
          DEFAULT: '#262626', // Slightly darker grey for muted elements
          foreground: '#A3A3A3', // Text on muted elements
        },

        // Primary Color (M3 Blue)
        primary: {
          DEFAULT: '#3B82F6',
          foreground: '#FFFFFF',
          container: '#DBEAFE', // Lighter shade for containers
          'on-container': '#1E40AF', // Darker text on primary container
        },
        // Secondary Color (M3 Green)
        secondary: {
          DEFAULT: '#10B981',
          foreground: '#FFFFFF',
          container: '#D1FAE5', // Lighter shade for containers
          'on-container': '#065F46', // Darker text on secondary container
        },
        // Tertiary Color (M3 Purple - renamed from accent)
        tertiary: {
          DEFAULT: '#8B5CF6',
          foreground: '#FFFFFF',
          container: 'hsl(250 100% 80%)', // Inferred lighter purple
          'on-container': 'hsl(250 100% 20%)', // Inferred darker text on tertiary container
        },

        // Semantic Colors
        'highlight-yellow': '#FACC15', // M3 Yellow for stars/coins
        error: {
          DEFAULT: '#EF4444', // M3 Red for errors
          foreground: '#FFFFFF',
        },
        success: '#10b981', // Same as secondary for positive status
        warning: '#f59e0b', // Existing orange for warnings

        // Shadcn UI component mappings
        destructive: { // Maps to error
          DEFAULT: 'var(--colors-error-DEFAULT)',
          foreground: 'var(--colors-error-foreground)',
        },
        card: {
          DEFAULT: 'var(--colors-surface)', // Card background is Neutral M3 Grey
          foreground: 'var(--colors-on-surface)', // Card text is white
        },
        popover: {
          DEFAULT: 'var(--colors-surface)', // Popover background is Neutral M3 Grey
          foreground: 'var(--colors-on-surface)', // Popover text is white
        },
        chart: { // Keep existing chart colors
          1: 'hsl(var(--chart-1))',
          2: 'hsl(var(--chart-2))',
          3: 'hsl(var(--chart-3))',
          4: 'hsl(var(--chart-4))',
          5: 'hsl(var(--chart-5))',
        },
      },
      keyframes: {
        'accordion-down': {
          from: {
            height: '0',
          },
          to: {
            height: 'var(--radix-accordion-content-height)',
          },
        },
        'accordion-up': {
          from: {
            height: 'var(--radix-accordion-content-height)',
          },
          to: {
            height: '0',
          },
        },
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
};
